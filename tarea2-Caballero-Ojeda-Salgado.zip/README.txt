Observaciones:

- La solución al problema se encuentra en el archivo problema.py
- Para ejecutarlo se debe hacer con el siguiente comando:
	python problema.py < entrada.txt
donde entrada.txt es cualquier archivo que contenga los datos de entrada.
- La solución está implementada en python 3.8 y fue probada en windows 10 y en ubuntu para windows.